============
Installation
============

Install the package with pip::

    $ do whatever you want I guess
    
.. _eg:

This is an example crossreference target.
