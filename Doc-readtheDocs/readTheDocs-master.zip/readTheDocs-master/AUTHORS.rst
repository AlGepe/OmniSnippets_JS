.. ==========
.. Title
.. ==========

.. Testing
.. ---------

.. moare testing
.. +++++++++++++

.. and moar (last shown on side index)
.. %%%%%%%%%%%

.. even moar
.. ############

.. Still a title
.. $$$$$$$$$$

.. not anymoar
.. ::::::::::::


========
Authors
========

Created by:
$$$$$$$$$$

* **Alvaro Diez** *Not an Astrophysicist™*
* **Dominik Czernia** *Mr. customJS wizzard himseld*


Proofread by:
$$$$$$$$$$
* **Jack Bowater** *It's you're not your*
.. Testing comments


Internal crossreferences, like example_.
And my own take, like1 :ref:`License<../README:license>`

And my own take, like2 :ref:`License<docs/readme:license>`

And my own take, like3 :ref:`License<readme:license>`

And my own take, like4 :ref:`License<README:license>`


And my own take, like5 :ref:`License`

And my own take, like :ref:`Custom<link2features>`

And my own take, like :ref:`Custom <link2features>`


And my own take, like :ref:`link2features`

==========
Title
==========

Testing
---------

moare testing
+++++++++++++

and moar (last shown on side index)
%%%%%%%%%%%

even moar
############

Still a title
$$$$$$$$$$

not anymoar
::::::::::::

.. all titles are shown on table of contents

.. _example:

This is an example crossreference target.
